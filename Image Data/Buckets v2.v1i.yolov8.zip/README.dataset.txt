# Buckets v2 > 2025-03-19 1:37pm
https://universe.roboflow.com/liverpoolrc/buckets-v2

Provided by a Roboflow user
License: CC BY 4.0

