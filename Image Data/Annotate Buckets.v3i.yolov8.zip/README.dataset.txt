# Annotate Buckets > 2025-03-12 2:25pm
https://universe.roboflow.com/liverpoolrc/annotate-buckets

Provided by a Roboflow user
License: CC BY 4.0

